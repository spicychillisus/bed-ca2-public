const currentURL = window.location.protocol + "//" + window.location.host
console.log(currentURL);

